@echo off
setlocal
set "DEMO_FILE=%~dp04B-MOS-Windows-Demo.html"
if not exist "%DEMO_FILE%" (
  echo ERROR: Extract the complete demo ZIP first.
  echo Keep this launcher next to 4B-MOS-Windows-Demo.html.
  pause
  exit /b 1
)
start "" "%DEMO_FILE%"
if errorlevel 1 (
  echo Open 4B-MOS-Windows-Demo.html with Microsoft Edge or Google Chrome.
  pause
  exit /b 1
)
exit /b 0
